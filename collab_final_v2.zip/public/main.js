// main.js v2 — improved save to disk: writes companies.json and project files under projects/<slug>/
let state = { users: {}, companies: {} }; // loaded from disk
let currentUser = null, currentCompany = null, cm = null;

async function loadFromDisk(){
  try{
    const r = await fetch('api.php?action=load');
    if(!r.ok) throw new Error('load failed');
    const j = await r.json(); state = j; console.log('Loaded', state);
  }catch(e){ console.warn('Could not load from disk, starting fresh', e); state = { users:{}, companies:{} }; }
}

async function saveToDisk(){
  const r = await fetch('api.php?action=save_all',{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(state) });
  const j = await r.json(); if(!j.ok) alert('Ошибка сохранения на диск: '+(j.error||'unknown')); else { console.log('Saved to disk'); refreshProjectsOnDisk(); }
}

function uid(){ return 'u'+Math.random().toString(36).slice(2,9); }
function slugify(s){ return s.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,''); }
function by(id){ return document.getElementById(id); }

async function init(){
  await loadFromDisk();
  bindUI(); renderCompaniesList();
  cm = CodeMirror.fromTextArea(by('editor'), {lineNumbers:true, mode:'application/x-httpd-php'});
  showPage('dashboard'); refreshProjectsOnDisk();
}

function bindUI(){
  by('register').onclick = ()=>{ const name=by('name').value, email=by('email').value, pass=by('password').value; if(!email||!pass){ alert('Email и пароль обязательны'); return; } if(state.users[email]){ alert('Пользователь уже есть'); return; } state.users[email]={id:uid(),name,email,pass}; saveToDisk(); alert('Зарегистрировано'); };
  by('login').onclick = ()=>{ const email=by('email').value, pass=by('password').value; if(state.users[email] && state.users[email].pass===pass){ currentUser=state.users[email]; showPage('companies'); } else alert('Неверный логин'); };
  by('logout').onclick = ()=>{ currentUser=null; showPage('dashboard'); };

  by('create_comp').onclick = ()=>{ const name=by('comp_name').value, pass=by('comp_pass').value; if(!name||!pass){ alert('Введите имя и пароль'); return; } const slug=slugify(name); if(state.companies[slug]){ alert('Компания уже есть'); return; } state.companies[slug]={id:slug,name,pass,files:{},messages:[]}; saveToDisk(); renderCompaniesList(); alert('Компания создана'); };
  by('join_comp').onclick = ()=>{ const slug=by('join_slug').value, pass=by('join_pass').value; if(!state.companies[slug]||state.companies[slug].pass!==pass){ alert('Компания не найдена или неверный пароль'); return; } currentCompany=slug; openProject(); };

  by('nav-dashboard').onclick = ()=>showPage('dashboard');
  by('nav-companies').onclick = ()=>showPage('companies');
  by('nav-project').onclick = ()=>{ if(currentCompany) openProject(); else alert('Сначала войдите в компанию'); };

  by('create_file').onclick = ()=>{ const p=by('new_path').value||'new.txt'; state.companies[currentCompany].files[p]=''; renderFiles(); saveToDisk(); };
  by('save_file').onclick = ()=>{ const p=by('edit_path').value; if(!p){ alert('Укажите путь'); return; } state.companies[currentCompany].files[p]=cm.getValue(); renderFiles(); saveToDisk(); alert('Файл сохранён в памяти и на диск'); };
  by('upload_btn').onclick = ()=>{ const f=by('upload_file').files[0]; if(!f){ alert('Файл не выбран'); return; } const r=new FileReader(); r.onload=function(){ state.companies[currentCompany].files[f.name]=r.result; renderFiles(); saveToDisk(); alert('Загружено и сохранено на диск'); }; r.readAsText(f); };

  by('chat_send').onclick = ()=>{ const name = by('chat_name').value || (currentUser?currentUser.name:'Anon'); const text = by('chat_text').value; state.companies[currentCompany].messages.push({name,text,time:new Date().toLocaleString()}); by('chat_text').value=''; renderChat(); saveToDisk(); };
  by('back_comp').onclick = ()=>{ currentCompany=null; showPage('companies'); };
  by('save_disk').onclick = ()=>{ saveToDisk(); };
  by('download_json').onclick = ()=>{ const data = JSON.stringify(state, null, 2); const blob = new Blob([data], {type:'application/json'}); const a=document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'companies_backup.json'; a.click(); };
}

function showPage(name){ document.querySelectorAll('.page').forEach(p=>p.classList.add('hidden')); document.querySelectorAll('.nav-btn').forEach(b=>b.classList.remove('active')); if(name==='dashboard'){ by('page-dashboard').classList.remove('hidden'); by('nav-dashboard').classList.add('active'); } if(name==='companies'){ by('page-companies').classList.remove('hidden'); by('nav-companies').classList.add('active'); } if(name==='project'){ by('page-project').classList.remove('hidden'); by('nav-project').classList.add('active'); } }

function renderCompaniesList(){ const ul=by('company_list'); ul.innerHTML=''; Object.keys(state.companies).forEach(k=>{ const li=document.createElement('li'); li.textContent = state.companies[k].name + ' (slug: '+k+')'; ul.appendChild(li); }); }

function openProject(){ showPage('project'); by('proj_title').textContent = state.companies[currentCompany].name; by('proj_slug').textContent = currentCompany; renderFiles(); renderChat(); }

function renderFiles(){ const list=by('file_list'); list.innerHTML=''; const files = state.companies[currentCompany].files || {}; Object.keys(files).forEach(path=>{ const li=document.createElement('li'); const a=document.createElement('a'); a.href='#'; a.textContent = path; a.onclick = (e)=>{ e.preventDefault(); by('edit_path').value=path; cm.setValue(files[path]); }; li.appendChild(a); list.appendChild(li); }); }

function renderChat(){ const el = by('chat_window'); el.innerHTML=''; const msgs = state.companies[currentCompany].messages || []; msgs.forEach(m=>{ const d=document.createElement('div'); d.className='chat-line'; d.innerHTML = '<b>'+escapeHtml(m.name)+'</b>: '+escapeHtml(m.text)+' <i class="time">('+m.time+')</i>'; el.appendChild(d); }); el.scrollTop = el.scrollHeight; }

function escapeHtml(s){ return (s+'').replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":"&#39;"}[c]; }); }

async function refreshProjectsOnDisk(){ const r = await fetch('api.php?action=list_projects'); if(r.ok){ const j=await r.json(); const ul=by('projects_on_disk'); ul.innerHTML=''; j.projects.forEach(p=>{ const li=document.createElement('li'); li.textContent = p; ul.appendChild(li); }); } }

window.addEventListener('load', init);

<?php
header('Content-Type: application/json');
$action = $_GET['action'] ?? '';
$base = realpath(__DIR__ . '/..');
$data_file = $base . '/data/companies.json';
$projects_dir = $base . '/projects';
if(!file_exists($projects_dir)) @mkdir($projects_dir, 0755, true);

if($action === 'load'){
    if(!file_exists($data_file)){
        $init = ['users'=>new stdClass(),'companies'=>new stdClass()];
        file_put_contents($data_file, json_encode($init, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }
    echo file_get_contents($data_file); exit;
}

if($action === 'save_all'){
    $body = file_get_contents('php://input');
    if(!$body){ echo json_encode(['ok'=>false,'error'=>'empty']); exit; }
    $j = json_decode($body, true);
    if($j === null){ echo json_encode(['ok'=>false,'error'=>'invalid_json']); exit; }
    // backup
    if(file_exists($data_file)) @copy($data_file, $data_file . '.bak_' . time());
    // write companies.json
    $w = file_put_contents($data_file, json_encode($j, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    if($w === false){ echo json_encode(['ok'=>false,'error'=>'write_failed_json']); exit; }
    // write project files for each company
    if(!empty($j['companies']) && is_array($j['companies'])){
        foreach($j['companies'] as $slug => $comp){
            $safe_slug = preg_replace('/[^a-z0-9\-_]/i','', $slug);
            $comp_dir = $projects_dir . '/' . $safe_slug;
            if(!file_exists($comp_dir)) @mkdir($comp_dir, 0755, true);
            // write each file
            if(!empty($comp['files']) && is_array($comp['files'])){
                foreach($comp['files'] as $path => $content){
                    $safe_path = str_replace('..','', $path);
                    $full = $comp_dir . '/' . $safe_path;
                    $d = dirname($full);
                    if(!file_exists($d)) @mkdir($d, 0755, true);
                    // write content (as text)
                    file_put_contents($full, $content);
                }
            }
        }
    }
    echo json_encode(['ok'=>true]); exit;
}

if($action === 'list_projects'){
    $projects = [];
    if(file_exists($projects_dir)){
        $it = new DirectoryIterator($projects_dir);
        foreach($it as $item){ if($item->isDir() && !$item->isDot()){ $projects[] = $item->getFilename(); } }
    }
    echo json_encode(['projects'=>$projects]); exit;
}

echo json_encode(['ok'=>false,'error'=>'no_action']);
?>

Collab final v2: saves project files to projects/<company_slug>/ and companies.json. Place into XAMPP htdocs.
